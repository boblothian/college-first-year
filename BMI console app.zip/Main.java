package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        String Name, category;
        double height, weight, bmi;

        Scanner sc = new Scanner(System.in);

        //get user input
        System.out.println("Please enter your name: ");
        Name = sc.next();

        System.out.println("Please enter your height (meters): ");
        height = sc.nextDouble();

        System.out.println("Please enter your weight (kg): ");
        weight = sc.nextDouble();

        Person person = new Person(Name, weight, height);

        System.out.println(person.getBMICategory());

    }
}