package com.company;

public class Person
{
    private String Name;
    private double weight, height;

    public Person (String name, double weight, double height)
    {
        setName(name);
        setWeight(weight);
        setHeight(height);
    }

    public String getBMICategory()
    {
        double bmi = weight / (height*height);
        String category;

        if (bmi <18.5)
        {
            category = "low";
        }

        else if (bmi <25)
        {
            category = "optimal";
        }

        else
        {
            category = "high";
        }
        return category;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

}
