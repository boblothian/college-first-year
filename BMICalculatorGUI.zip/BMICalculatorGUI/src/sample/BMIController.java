package sample;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class BMIController {
    @FXML private TextField bmiTextField, categoryTextField;

    private Person person;

    public void setPerson (Person person)
    {
        this.person = person;

        bmiTextField.setText("" + person.getBMI());
        categoryTextField.setText(person.getCategory());
    }

    public void initialize(){

    }
}
