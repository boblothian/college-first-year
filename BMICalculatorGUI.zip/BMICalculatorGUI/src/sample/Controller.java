package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.xml.soap.Node;
import javax.xml.transform.Result;
import java.io.IOException;

public class Controller {
    @FXML private Button submitButton;
    @FXML private TextField nameTextField, heightTextField, weightTextField;
    @FXML private Label bmiResult;

    private Person person;

    public void initialize(){

        submitButton.setOnAction((event) -> {
            String name = nameTextField.getText().toString();
            double height = Double.parseDouble(heightTextField.getText().toString());
            double weight = Double.parseDouble(weightTextField.getText().toString());

            person = new Person (name, height, weight);
            bmiResult.setText("hello " + person.getName() + " your category is "+ person.getCategory());
        });

    }
}
