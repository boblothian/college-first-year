package sample;

public class Person {
    private String name;
    private double height;
    private double weight;

    public Person (String name, double height, double weight)
    {
        setName (name);
        setHeight (height);
        setWeight (weight);
    }

    public String getName()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public double getHeight ()
    {
        return height;
    }

    public void setHeight(double height)
    {
        this.height = height;
    }

    public double getWeight()
    {
        return weight;
    }

    public void setWeight (double weight)
    {
        this.weight = weight;
    }

    public double getBMI()
    {
        return weight/(height * height);
    }

    public String getCategory()
    {
        if (getBMI() <18.5)
        {
            return "Underweight";
        }
        else if (getBMI() <25)
        {
            return "Normal";
        }
        else
        {
            return "Overweight";
        }
    }
}