package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Random;


public class Controller
{
    @FXML private Button generateButton;
    @FXML private TextField fNameText, sNameText;
    @FXML private Label displayUsername;

    private Person person;

    public void initialize()
    {
        generateButton.setOnAction((event) ->
        {
            String fName = fNameText.getText().toString();
            String sName = sNameText.getText().toString();

            person = new Person (fName, sName);
            String halfSurname = sName.substring(0,(sName.length()/2));
            Random rng = new Random();
            int n = rng.nextInt(100);
            displayUsername.setText("Your user name is : "+ fName.charAt(0) + halfSurname +(n+1));
        });
    }
}
