package sample;

public class Athlete {

    private String name;
    private double time;

    public Athlete (String name, Double time)
    {
        setName(name);
        setTime(time);
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public double getTime()
    {
        return time;
    }

    public void setTime(double time)
    {
        this.time = time;
    }

    public boolean compareTo(Athlete athleteResult) {
        return false;
    }
}
