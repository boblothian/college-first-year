package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.util.Arrays;

public class Controller {

    @FXML ListView resultList;
    @FXML Button resultsButton, sortButton;
    private static Leaderboard leaderboard = new Leaderboard();

    public void initialize()
    {
        resultsButton.setOnAction((event) ->
        {
            DisplayArray();
        });
        sortButton.setOnAction((event) ->
        {
            DisplaySorted();
        });
    }

    public void DisplaySorted()
    {
        Athlete temp;
        {
            int arrayLength = leaderboard.athleteResults.length;
            for (int i=0; i<arrayLength-1; i++)
            {
                for (int j = 1; j <arrayLength; j++) {
                    if (this.leaderboard.athleteResults[j-1].getTime()>(this.leaderboard.athleteResults[j].getTime()))
                    {
                        temp = leaderboard.athleteResults[j-1];
                        leaderboard.athleteResults[j-1] = leaderboard.athleteResults[j];
                        leaderboard.athleteResults[j] = temp;
                    }
                }
            }
            DisplayArray();
        }
    }

    public void DisplayArray()
    {
        this.resultList.getItems().clear();
        for (Athlete a : leaderboard.athleteResults)
        {
            String name = a.getName();
            Double time = a.getTime();
            String displayResults = name + " - " + time;

            this.resultList.getItems().add(displayResults);
        }
    }
}