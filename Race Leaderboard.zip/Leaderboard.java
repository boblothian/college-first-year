package sample;

public class Leaderboard
{
    Athlete athleteResults[];


    public Leaderboard()
    {
        this.athleteResults = new Athlete[10];
        this.SetupAthletes();
    }

    public void SetupAthletes()
    {
        if (this.athleteResults.length > 0)
        {
            athleteResults[0] = new Athlete("Richard Thompson", 9.82);
            athleteResults[1] = new Athlete("Nesta Carter", 9.78);
            athleteResults[2] = new Athlete("Usain Bolt", 9.92);
            athleteResults[3] = new Athlete("Asafa Powell", 9.72);
            athleteResults[4] = new Athlete("Tyson Gay", 9.69);
            athleteResults[5] = new Athlete("Maurice Green", 9.79);
            athleteResults[6] = new Athlete("Justin Gatlin", 9.74);
            athleteResults[7] = new Athlete("Christian Coleman", 9.76);
            athleteResults[8] = new Athlete("Yohan Blake", 9.69);
            athleteResults[9] = new Athlete("Steve Mullings", 9.80);
        }

        else
        {
            System.out.println("Athlete results not created");
        }
    }

}
