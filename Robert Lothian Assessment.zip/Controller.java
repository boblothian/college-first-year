package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;


public class Controller {
    @FXML Button addMark, submit;
    @FXML TextField textBox;
    @FXML Label errorMessage;


    public void initialize() {

            addMark.setOnAction((event) -> { //on press of add mark button execute following code
            String storedValue = textBox.getText(); //store value from text box
                Integer.parseInt(storedValue); //change value from string to int
            StoredMarks.add(storedValue);//adds the entered value into the array


            textBox.setText("");//clears the text box
        });

        submit.setOnAction((event) -> { //on button press load second page

            if (StoredMarks.getTotal() == 0) //code to write error message if user hits submit without entering a mark
            {
                errorMessage.setText("You have not entered a mark, try again.");
            }

            else
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SecondPage.fxml"));
                Parent root = loader.load();

                Scene scene = new Scene(root);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }
            catch (IOException e) {
            }
        });
    }


}

