package sample;

import java.util.ArrayList;
import java.util.Collections;

public class StoredMarks {

    private static ArrayList<Integer> storedMarks = new ArrayList<>();//creates new array list to store marks

    public static void add(String s) { //adds value entered into array and parses as an int

        storedMarks.add(Integer.valueOf(s));
    }


    public static int getTotal(){ //get total number of marks entered

        return storedMarks.size();
    }

    public static int getAverage(){ //get average number of marks entered

        return getSum()/getTotal();
    }

    public static int getSum(){ //get total of marks entered

        int sum = 0;
        for (Integer element : storedMarks)
        {
            sum += Integer.parseInt(String.valueOf(element));
        }
        return sum;
    }



    public static int highestMark() //get highest mark
    {
        Collections.sort(storedMarks);
        return storedMarks.get(0+ storedMarks.size()-1);
    }

    public static int lowestMark() //get lowest mark
    {

        Collections.sort(storedMarks);
        return storedMarks.get(0);
    }
}

